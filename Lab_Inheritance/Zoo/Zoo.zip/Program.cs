﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    class Program
    {
        static void Main(string[] args)
        {
         //  Animal animal = new Animal();
         //  animal.Eat();
         //
         //  Dog dog = new Dog();
         //  dog.Bark();
         //  dog.Eat();
         //
         //  Puppy puppy = new Puppy();
         //  puppy.Weep();
         //  puppy.Bark();
         //  puppy.Eat();
         //
         //  Cat cat = new Cat();
         //  cat.Meow();
         //  cat.Eat();

        }
    }
}
